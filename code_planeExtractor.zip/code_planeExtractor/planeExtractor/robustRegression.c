#include <malloc.h>
#include <math.h>
#include "solveEquationAndEigen.h"
#include "matrixANDvector.h"
#include "sorting.h"

#define outputInfo 0
#define outlierNum 0  //�ų������ݸ���(����ʹ�á����������bias)
#define distMode 1 //����ƽ�浽ԭ������ȡ����1Ϊ��λ������0Ϊƽ������,ƽ������׼ȷ���Եͣ������ٶȼ��죬�ʺ������ٵĵ���

//Last Updated 2021.3.8
//������solveEquationAndEigen.c  matrixANDvector.c  sorting.c


//����һ��ƽ�漯�������ƽ�棬��С��λ����(���ƻ�ԭ�е㼯��
//���������������,��7��ֵ��ǰ��λ�ǵ�λ������������λ��ƽ�浽ԭ����룬֮�������ǵ㼯�ĺ�ȣ�����
void planeLMedS(double **pt, int numPt, double *result)
{
	double xbar = 0, ybar = 0, zbar = 0;
	for (int i = 0; i < numPt; i++)
	{
		xbar += pt[i][0];
		ybar += pt[i][1];
		zbar += pt[i][2];
	}
	xbar /= numPt;
	ybar /= numPt;
	zbar /= numPt;
	for (int i = 0; i < numPt; i++)
	{
		pt[i][0] -= xbar;
		pt[i][1] -= ybar;
		pt[i][2] -= zbar;
	}
	double **cov = createMatrix(3, 3);
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			cov[i][j] = 0;
	for (int i = 0; i < numPt; i++)
	{
		cov[0][0] += pt[i][0] * pt[i][0];
		cov[0][1] += pt[i][0] * pt[i][1];
		cov[0][2] += pt[i][0] * pt[i][2];
		cov[1][1] += pt[i][1] * pt[i][1];
		cov[1][2] += pt[i][1] * pt[i][2];
		cov[2][2] += pt[i][2] * pt[i][2];
	}
	cov[1][0] = cov[0][1];
	cov[2][0] = cov[0][2];
	cov[2][1] = cov[1][2];
	if (outputInfo)
	{
		printf("Covariance matrix is: \n");
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
				printf("%lf ", cov[i][j]);
			printf("\n");
		}
	}
	double vector[3];
	int numEigen = eigen3(cov, vector);
	if (numEigen < 3)printf("Warning! Errounous point set.\n");
	for (int i = 0; i < 3; i++)
		result[i + 4] = sqrt(vector[i] / numPt);
	if (outputInfo)
	{
		printf("\nNumber of eigen value(s): %d\n, They are: ", numEigen);
		for (int i = 0; i < numEigen; i++)
			printf("%lf ", vector[i]);
		printf("\nRange in each dimension is:\n");
		for (int i = 0; i < numEigen; i++)
			if (vector[i] >= 0)
				printf("%lf ", sqrt(vector[i] / numPt));
		printf("\n");
	}
	double eig = vector[0];
	if (numEigen > 1)
		if (fabs(eig) > fabs(vector[1]))eig = vector[1];
	if (numEigen > 2)
		if (fabs(eig) > fabs(vector[2]))eig = vector[2];
	eigen3vec(cov, eig, vector);
	if (outputInfo)
	{
		printf("\nChosen eigen value: %lf\nUpdated covariance matrix is: \n", eig);
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
				printf("%lf ", cov[i][j]);
			printf("\n");
		}
		printf("Eigen vector:\n");
		for (int i = 0; i < 3; i++)
			printf("%lf ", vector[i]);
		printf("\n");
	}

	double d;
	if (distMode)
	{
		double *dist = (double*)malloc(sizeof(double)*numPt);
		for (int i = 0; i < numPt; i++)
		{
			pt[i][0] += xbar;
			pt[i][1] += ybar;
			pt[i][2] += zbar;
		}
		for (int i = 0; i < numPt; i++)
			dist[i] = product3(vector, pt[i]);
		autoMergeSort(dist, numPt);
		if ((numPt - outlierNum) % 2)d = dist[(numPt - outlierNum + 1) / 2 - 1];
		else d = (dist[(numPt - outlierNum) / 2 - 1] + dist[(numPt - outlierNum) / 2]) / 2;
		free(dist);
	}
	else
	{
		d = vector[0] * xbar + vector[1] * ybar + vector[2] * zbar;
	}

	if (d < 0)
	{
		for (int i = 0; i < 3; i++)
			result[i] = -vector[i];
		result[3] = -d;
	}
	else
	{
		for (int i = 0; i < 3; i++)
			result[i] = vector[i];
		result[3] = d;
	}
	free(cov[0]);
	free(cov);
}

//����һ��ƽ�漯�������ƽ�棬��С��λ����(�����ƻ�ԭ�е㼯��
//���������������,��7��ֵ��ǰ��λ�ǵ�λ������������λ��ƽ�浽ԭ����룬֮�������ǵ㼯�ĺ�ȣ�����
void planeLMedS_safe(double **pt, int numPt, double *result)
{
	double xbar = 0, ybar = 0, zbar = 0;
	for (int i = 0; i < numPt; i++)
	{
		xbar += pt[i][0];
		ybar += pt[i][1];
		zbar += pt[i][2];
	}
	xbar /= numPt;
	ybar /= numPt;
	zbar /= numPt;
	double **pt2 = createMatrix(numPt, 3);
	for (int i = 0; i < numPt; i++)
	{
		pt2[i][0] = pt[i][0] - xbar;
		pt2[i][1] = pt[i][1] - ybar;
		pt2[i][2] = pt[i][2] - zbar;
	}
	double **cov = createMatrix(3, 3);
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			cov[i][j] = 0;
	for (int i = 0; i < numPt; i++)
	{
		cov[0][0] += pt2[i][0] * pt2[i][0];
		cov[0][1] += pt2[i][0] * pt2[i][1];
		cov[0][2] += pt2[i][0] * pt2[i][2];
		cov[1][1] += pt2[i][1] * pt2[i][1];
		cov[1][2] += pt2[i][1] * pt2[i][2];
		cov[2][2] += pt2[i][2] * pt2[i][2];
	}
	cov[1][0] = cov[0][1];
	cov[2][0] = cov[0][2];
	cov[2][1] = cov[1][2];
	if (outputInfo)
	{
		printf("Covariance matrix is: \n");
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
				printf("%lf ", cov[i][j]);
			printf("\n");
		}
	}
	double vector[3];
	int numEigen = eigen3(cov, vector);
	if (numEigen < 3)printf("Warning! Errounous point set.\n");
	for (int i = 0; i < 3; i++)
		result[i + 4] = sqrt(vector[i] / numPt);
	if (outputInfo)
	{
		printf("\nNumber of eigen value(s): %d\n, They are: ", numEigen);
		for (int i = 0; i < numEigen; i++)
			printf("%lf ", vector[i]);
		printf("\nRange in each dimension is:\n");
		for (int i = 0; i < numEigen; i++)
			if (vector[i] >= 0)
				printf("%lf ", sqrt(vector[i] / numPt));
		printf("\n");
	}
	double eig = vector[0];
	if (numEigen > 1)
		if (fabs(eig) > fabs(vector[1]))eig = vector[1];
	if (numEigen > 2)
		if (fabs(eig) > fabs(vector[2]))eig = vector[2];
	eigen3vec(cov, eig, vector);
	if (outputInfo)
	{
		printf("\nChosen eigen value: %lf\nUpdated covariance matrix is: \n", eig);
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
				printf("%lf ", cov[i][j]);
			printf("\n");
		}
		printf("Eigen vector:\n");
		for (int i = 0; i < 3; i++)
			printf("%lf ", vector[i]);
		printf("\n");
	}
	double d;
	if (distMode)
	{
		double *dist = (double*)malloc(sizeof(double)*numPt);
		for (int i = 0; i < numPt; i++)
		{
			pt[i][0] += xbar;
			pt[i][1] += ybar;
			pt[i][2] += zbar;
		}
		for (int i = 0; i < numPt; i++)
			dist[i] = product3(vector, pt[i]);
		autoMergeSort(dist, numPt);
		if ((numPt - outlierNum) % 2)d = dist[(numPt - outlierNum + 1) / 2 - 1];
		else d = (dist[(numPt - outlierNum) / 2 - 1] + dist[(numPt - outlierNum) / 2]) / 2;
		free(dist);
	}
	else
	{
		d = vector[0] * xbar + vector[1] * ybar + vector[2] * zbar;
	}

	if (d < 0)
	{
		for (int i = 0; i < 3; i++)
			result[i] = -vector[i];
		result[3] = -d;
	}
	else
	{
		for (int i = 0; i < 3; i++)
			result[i] = vector[i];
		result[3] = d;
	}
	free(pt2[0]);
	free(cov[0]);
	free(pt2);
	free(cov);
}