#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <time.h>
//Last updated 2021.3.19

#define threshold_angle 0.5 //������н�С�ڴ�ֵ�϶�Ϊƽ�У�������ԽСԽ�죬����������Ʊ������Ȳ���ʱ����ʧ�ܣ�����������������
#define samePl_normal 0.1  //����ƽ��normal vector�и���ֵ����С�ڴ�ֵ��Ϊ��ͬ
//������3.5��������3Dģ����׼ʱ��������������ϴ�����һ����43.5����,����103.5,hololens����7.5
#define samePl_dist 3.5  //����ƽ������С�ڴ�ֵ��Ϊ��ͬ,singleMatchģʽӦ����Сһ�㣬�����һЩ
#define singleMatch 0 //�ȶ�ʱ�Ƿ�ǿ��һһ��Ӧ��������ƿɿ��̶Ⱥܸ߿�������
#define numOnly 1  //�Ƿ������ƥ���ƽ����������׼����û�����Ļ��ᰴ��Ӧ������
#define finalOptimization 1 //1�������Ż������Ż�rot�����Ż�tran��2��homogenous�Ż���ͬʱ�Ż�����
#define finalOptimization_tran 1

#define testmode 0
#define debugmode 0
#define weighted 0 //�Ƿ���ƽ��Ȩ��,�ǵĻ����ȡƽ��ĵ����������Ȳ��������û����Щ����ѡ��
#define finalCheck 0 //�Ƿ����ռ�����Ƿ񳬳�������Χ
//slam��Ӧ�ã��±�����ֵ��1,5,50�ȽϺ���
#define pitch_roll_restriction 0 //�Ƿ��roll��pitch�Ľ����Χ��������,�ǵĻ������ֵ������������Ƕ�,int��������Ϊ0
#define yaw_restriction 0
#define translation_restriction 0 //λ�������������ƣ�int��������Ϊ0
#define flip_planes 0 //�Ƿ���ƽ�淭ת���

#define PI 3.14159265358979323846
#define max_Pl 200  //ÿ��ƽ�漯���������ƽ����
#define max_Des 10507200 //���descriptor����
#define threshold_linear 0.01 //����ʽ����ֵС�ڴ�ֵ�϶�Ϊ0

#define ground_truth_provided 0
#define GTyaw 30.0
#define GTpitch 30.0
#define GTroll 30.0
#define GTtx 100.0
#define GTty 100.0
#define GTtz 100.0

#define min(a,b) (((a) < (b)) ? (a) : (b))
FILE *fpdb;
double deg;

double **pl1;//����ƽ�漯1��7λ�ƣ�ǰ3λ�ǵ�λ������������λ�ǵ�ԭ�����,֮���Ǻ�ȣ�������
int *plPts1;//ÿ��ƽ�����ж��ٸ���
double **pl2;
int *plPts2;

double **des1;//ƽ����ϵ�descriptor��15λ��ǰ��λ������ƽ�淨�����н���С����֮��������������������������潻������
int numDes1;//ƽ����ϵ���Чdescriptor����
double **des2;
int numDes2;

double det3(double **m);
int rev3(double **m, double **result);
double ang(double *v1, double *v2);
void svdApprox(double **m, int n);
void optimize_rot(int **matchList, int numMatch, double **pl1, double **pl2, double **rot, double **normal1, double **normal2, double **tmp33, double **rev, double *weight);
void optimize_tran(int **matchList, int numMatch, double **pl1, double **pl2, double **rot, double **normal2, double **tmp33, double **rev, double *tran, double *weight);
void optimize_homogeneous(int **matchList, int numMatch, double **pl1, double **pl2, double **rot, double **normal1, double **normal2, double **tmp33, double **rev, double *tran, double *weight);
int main(int argc, char* argv[])
{
	clock_t currentTime;
	currentTime = clock();

	FILE *fp;
	if (testmode)fp = fopen("C:\\Users\\Administrator\\Desktop\\reg\\1_planeSet.txt", "r");
	else fp = fopen(argv[1], "r");
	FILE *fp2;
	if (testmode)fp2 = fopen("C:\\Users\\Administrator\\Desktop\\reg\\2_planeSet.txt", "r");
	else fp2 = fopen(argv[2], "r");
	FILE *fp3;
	if (testmode)fp3 = fopen("C:\\Users\\Administrator\\Desktop\\reg\\registration_result.txt", "w");
	else fp3 = fopen("registration_result.txt", "w");
	FILE *fp4;
	if (testmode)fp4 = fopen("C:\\Users\\Administrator\\Desktop\\reg\\registration_result_motion.txt", "w");
	else fp4 = fopen("registration_result_motion.txt", "w");

	pl1 = (double**)malloc(sizeof(double*)*max_Pl);
	for (int i = 0; i < max_Pl; i++)
		pl1[i] = (double*)malloc(sizeof(double) * 7);
	plPts1 = (int*)malloc(sizeof(int)*max_Pl);
	pl2 = (double**)malloc(sizeof(double*)*max_Pl);
	for (int i = 0; i < max_Pl; i++)
		pl2[i] = (double*)malloc(sizeof(double) * 7);
	plPts2 = (int*)malloc(sizeof(int)*max_Pl);

	int numPl1 = 0, numPl2 = 0, read;
	if (weighted)
	{
		read = fscanf(fp, "%lf %lf %lf %lf %lf %lf %lf %d\n", &pl1[numPl1][0], &pl1[numPl1][1], &pl1[numPl1][2], &pl1[numPl1][3], &pl1[numPl1][4], &pl1[numPl1][5], &pl1[numPl1][6], &plPts1[numPl1]);
		while (read != EOF)
		{
			numPl1++;
			read = fscanf(fp, "%lf %lf %lf %lf %lf %lf %lf %d\n", &pl1[numPl1][0], &pl1[numPl1][1], &pl1[numPl1][2], &pl1[numPl1][3], &pl1[numPl1][4], &pl1[numPl1][5], &pl1[numPl1][6], &plPts1[numPl1]);
		}
		fclose(fp);
	}
	else
	{
		read = fscanf(fp, "%lf %lf %lf %lf", &pl1[numPl1][0], &pl1[numPl1][1], &pl1[numPl1][2], &pl1[numPl1][3]);
		while (read != EOF)
		{
			do { read = fgetc(fp); } while (read != '\n');
			numPl1++;
			read = fscanf(fp, "%lf %lf %lf %lf", &pl1[numPl1][0], &pl1[numPl1][1], &pl1[numPl1][2], &pl1[numPl1][3]);
		}
		fclose(fp);
	}

	if (numPl1 < 3)
	{
		printf("Fail: Not enough plane\nPress any key to exit...\n");
		//���ʧ�ܽ��
		fprintf(fp3, "Fail. No match found.\nRotation Matrix:\n");
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
				fprintf(fp3, "%lf ", (i == j) ? 1.0 : 0.0);
			fprintf(fp3, "\n");
		}
		fprintf(fp3, "Rotation:\nYaw:%lf deg\nPitch:%lf deg\nRoll:%lf deg\n", 0.0, 0.0, 0.0);
		fprintf(fp3, "Translation:\n");
		for (int i = 0; i < 3; i++)
			fprintf(fp3, "%lf ", 0.0);
		fprintf(fp3, "\n");
		fprintf(fp3, "Matching planes: %d\n", 0);

		fprintf(fp4, "%lf yaw\n", 0.0);
		fprintf(fp4, "%lf pitch\n", 0.0);
		fprintf(fp4, "%lf roll\n", 0.0);
		fprintf(fp4, "%lf tx\n", 0.0);
		fprintf(fp4, "%lf ty\n", 0.0);
		fprintf(fp4, "%lf tz\n", 0.0);
		//getch();
		return 0;
	}
	if (weighted)
	{
		read = fscanf(fp2, "%lf %lf %lf %lf %lf %lf %lf %d\n", &pl2[numPl2][0], &pl2[numPl2][1], &pl2[numPl2][2], &pl2[numPl2][3], &pl2[numPl2][4], &pl2[numPl2][5], &pl2[numPl2][6], &plPts2[numPl2]);
		while (read != EOF)
		{
			numPl2++;
			read = fscanf(fp2, "%lf %lf %lf %lf %lf %lf %lf %d\n", &pl2[numPl2][0], &pl2[numPl2][1], &pl2[numPl2][2], &pl2[numPl2][3], &pl2[numPl2][4], &pl2[numPl2][5], &pl2[numPl2][6], &plPts2[numPl2]);
		}
		fclose(fp2);
	}
	else
	{
		read = fscanf(fp2, "%lf %lf %lf %lf", &pl2[numPl2][0], &pl2[numPl2][1], &pl2[numPl2][2], &pl2[numPl2][3]);
		while (read != EOF)
		{
			do { read = fgetc(fp2); } while (read != '\n');
			numPl2++;
			read = fscanf(fp2, "%lf %lf %lf %lf", &pl2[numPl2][0], &pl2[numPl2][1], &pl2[numPl2][2], &pl2[numPl2][3]);
		}
		fclose(fp2);
	}
	if (numPl2 < 3)
	{
		printf("Fail: Not enough plane\nPress any key to exit...\n");
		//���ʧ�ܽ��
		fprintf(fp3, "Fail. No match found.\nRotation Matrix:\n");
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
				fprintf(fp3, "%lf ", (i == j) ? 1.0 : 0.0);
			fprintf(fp3, "\n");
		}
		fprintf(fp3, "Rotation:\nYaw:%lf deg\nPitch:%lf deg\nRoll:%lf deg\n", 0.0, 0.0, 0.0);
		fprintf(fp3, "Translation:\n");
		for (int i = 0; i < 3; i++)
			fprintf(fp3, "%lf ", 0.0);
		fprintf(fp3, "\n");
		fprintf(fp3, "Matching planes: %d\n", 0);

		fprintf(fp4, "%lf yaw\n", 0.0);
		fprintf(fp4, "%lf pitch\n", 0.0);
		fprintf(fp4, "%lf roll\n", 0.0);
		fprintf(fp4, "%lf tx\n", 0.0);
		fprintf(fp4, "%lf ty\n", 0.0);
		fprintf(fp4, "%lf tz\n", 0.0);
		//getch();
		return 0;
	}
	printf("Reading completed. %d, %d planes acquired.\n", numPl1, numPl2);

	deg = PI / 180;
	//printf("%lf\n", acos(-0.5) / deg);

	numDes1 = 0;
	numDes2 = 0;
	des1 = (double**)malloc(sizeof(double*)*max_Des);
	des2 = (double**)malloc(sizeof(double*)*max_Des);
	double **rep;//��������ķ�������һ���������
	rep = (double**)malloc(sizeof(double*) * 3);
	for (int i = 0; i < 3; i++)
		rep[i] = (double*)malloc(sizeof(double) * 3);
	double **rev;//�������������
	rev = (double**)malloc(sizeof(double*) * 3);
	for (int i = 0; i < 3; i++)
		rev[i] = (double*)malloc(sizeof(double) * 3);
	double *point;//������Ľ���
	point = (double*)malloc(sizeof(double) * 3);
	double angle1, angle2, angle3;//�������н�

	for (int i = 0; i < numPl1 - 2; i++)
		for (int j = i + 1; j < numPl1 - 1; j++)
			for (int k = j + 1; k < numPl1; k++)
			{
				for (int m = 0; m < 3; m++)
					rep[m][0] = pl1[i][m];
				for (int m = 0; m < 3; m++)
					rep[m][1] = pl1[j][m];
				for (int m = 0; m < 3; m++)
					rep[m][2] = pl1[k][m];
				if (fabs(det3(rep)) < threshold_linear)continue;//�������������棬��Ч
				angle1 = ang(pl1[i], pl1[j]) / deg;
				angle2 = ang(pl1[i], pl1[k]) / deg;
				angle3 = ang(pl1[j], pl1[k]) / deg;
				rev3(rep, rev);
				flip(rev);
				point[0] = pl1[i][3];
				point[1] = pl1[j][3];
				point[2] = pl1[k][3];
				leftMult(rev, point);
				if (flip_planes)
				{
					for (int m = 0; m < 8; m++)//����ת
					{
						des1[numDes1] = (double*)malloc(sizeof(double) * 15);
						des1[numDes1][0] = angle1;
						des1[numDes1][1] = angle2;
						des1[numDes1][2] = angle3;
						for (int n = 0; n < 3; n++)
							des1[numDes1][n + 3] = pl1[i][n];
						for (int n = 0; n < 3; n++)
							des1[numDes1][n + 6] = pl1[j][n];
						for (int n = 0; n < 3; n++)
							des1[numDes1][n + 9] = pl1[k][n];
						for (int n = 0; n < 3; n++)
							des1[numDes1][n + 12] = point[n];
						numDes1++;
					}

					for (int n = 0; n < 3; n++)//��תi
						des1[numDes1 - 7][n + 3] *= -1;
					des1[numDes1 - 7][0] = 180 - des1[numDes1 - 7][0];
					des1[numDes1 - 7][1] = 180 - des1[numDes1 - 7][1];

					for (int n = 0; n < 3; n++)//��תj
						des1[numDes1 - 6][n + 6] *= -1;
					des1[numDes1 - 6][0] = 180 - des1[numDes1 - 6][0];
					des1[numDes1 - 6][2] = 180 - des1[numDes1 - 6][2];

					for (int n = 0; n < 3; n++)//��תk
						des1[numDes1 - 5][n + 9] *= -1;
					des1[numDes1 - 5][1] = 180 - des1[numDes1 - 5][1];
					des1[numDes1 - 5][2] = 180 - des1[numDes1 - 5][2];

					for (int n = 0; n < 3; n++)//��תi
						des1[numDes1 - 4][n + 3] *= -1;
					for (int n = 0; n < 3; n++)//��תj
						des1[numDes1 - 4][n + 6] *= -1;
					des1[numDes1 - 4][1] = 180 - des1[numDes1 - 4][1];
					des1[numDes1 - 4][2] = 180 - des1[numDes1 - 4][2];

					for (int n = 0; n < 3; n++)//��תi
						des1[numDes1 - 3][n + 3] *= -1;
					for (int n = 0; n < 3; n++)//��תk
						des1[numDes1 - 3][n + 9] *= -1;
					des1[numDes1 - 3][0] = 180 - des1[numDes1 - 3][0];
					des1[numDes1 - 3][2] = 180 - des1[numDes1 - 3][2];

					for (int n = 0; n < 3; n++)//��תj
						des1[numDes1 - 2][n + 6] *= -1;
					for (int n = 0; n < 3; n++)//��תk
						des1[numDes1 - 2][n + 9] *= -1;
					des1[numDes1 - 2][0] = 180 - des1[numDes1 - 2][0];
					des1[numDes1 - 2][1] = 180 - des1[numDes1 - 2][1];

					for (int n = 0; n < 3; n++)//��תi
						des1[numDes1 - 1][n + 3] *= -1;
					for (int n = 0; n < 3; n++)//��תj
						des1[numDes1 - 1][n + 6] *= -1;
					for (int n = 0; n < 3; n++)//��תk
						des1[numDes1 - 1][n + 9] *= -1;
				}
				else
				{
					des1[numDes1] = (double*)malloc(sizeof(double) * 15);
					des1[numDes1][0] = angle1;
					des1[numDes1][1] = angle2;
					des1[numDes1][2] = angle3;
					for (int n = 0; n < 3; n++)
						des1[numDes1][n + 3] = pl1[i][n];
					for (int n = 0; n < 3; n++)
						des1[numDes1][n + 6] = pl1[j][n];
					for (int n = 0; n < 3; n++)
						des1[numDes1][n + 9] = pl1[k][n];
					for (int n = 0; n < 3; n++)
						des1[numDes1][n + 12] = point[n];
					numDes1++;
				}
			}
	double tmp;//����
	for (int i = 0; i < numDes1; i++)
	{
		if (des1[i][0] > des1[i][1])
		{
			tmp = des1[i][0];
			des1[i][0] = des1[i][1];
			des1[i][1] = tmp;
			for (int j = 6; j < 9; j++)
			{
				tmp = des1[i][j];
				des1[i][j] = des1[i][j + 3];
				des1[i][j + 3] = tmp;
			}
		}
		if (des1[i][0] > des1[i][2])
		{
			tmp = des1[i][0];
			des1[i][0] = des1[i][2];
			des1[i][2] = tmp;
			for (int j = 3; j < 6; j++)
			{
				tmp = des1[i][j];
				des1[i][j] = des1[i][j + 6];
				des1[i][j + 6] = tmp;
			}
		}
		if (des1[i][1] > des1[i][2])
		{
			tmp = des1[i][1];
			des1[i][1] = des1[i][2];
			des1[i][2] = tmp;
			for (int j = 3; j < 6; j++)
			{
				tmp = des1[i][j];
				des1[i][j] = des1[i][j + 3];
				des1[i][j + 3] = tmp;
			}
		}
	}//des1�������

	//���һ��descriptor�ĸ����Ǵ�С�ǳ��ӽ���������3������90�ȣ�����Ҫ������������˳��
	int additional = 0;
	for (int i = 0; i < numDes1; i++)
	{
		if (des1[i][1] - des1[i][0] < threshold_angle)
		{
			if (des1[i][2] - des1[i][0] < threshold_angle)//�����Ƕ��ܽӽ�
			{
				//��������1-3-2
				des1[numDes1 + additional] = (double*)malloc(sizeof(double) * 15);
				des1[numDes1 + additional][0] = des1[i][0];
				des1[numDes1 + additional][1] = des1[i][2];
				des1[numDes1 + additional][2] = des1[i][1];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 3] = des1[i][n + 6];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 6] = des1[i][n + 3];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 9] = des1[i][n + 9];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 12] = des1[i][n + 12];
				additional++;
				//��������2-1-3
				des1[numDes1 + additional] = (double*)malloc(sizeof(double) * 15);
				des1[numDes1 + additional][0] = des1[i][1];
				des1[numDes1 + additional][1] = des1[i][0];
				des1[numDes1 + additional][2] = des1[i][2];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 3] = des1[i][n + 3];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 6] = des1[i][n + 9];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 9] = des1[i][n + 6];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 12] = des1[i][n + 12];
				additional++;
				//��������2-3-1
				des1[numDes1 + additional] = (double*)malloc(sizeof(double) * 15);
				des1[numDes1 + additional][0] = des1[i][1];
				des1[numDes1 + additional][1] = des1[i][2];
				des1[numDes1 + additional][2] = des1[i][0];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 3] = des1[i][n + 9];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 6] = des1[i][n + 3];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 9] = des1[i][n + 6];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 12] = des1[i][n + 12];
				additional++;
				//��������3-1-2
				des1[numDes1 + additional] = (double*)malloc(sizeof(double) * 15);
				des1[numDes1 + additional][0] = des1[i][2];
				des1[numDes1 + additional][1] = des1[i][0];
				des1[numDes1 + additional][2] = des1[i][1];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 3] = des1[i][n + 6];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 6] = des1[i][n + 9];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 9] = des1[i][n + 3];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 12] = des1[i][n + 12];
				additional++;
				//��������3-2-1
				des1[numDes1 + additional] = (double*)malloc(sizeof(double) * 15);
				des1[numDes1 + additional][0] = des1[i][2];
				des1[numDes1 + additional][1] = des1[i][1];
				des1[numDes1 + additional][2] = des1[i][0];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 3] = des1[i][n + 9];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 6] = des1[i][n + 6];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 9] = des1[i][n + 3];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 12] = des1[i][n + 12];
				additional++;
			}
			else //ֻ��1,2�ܽӽ�
			{
				//��������2-1-3
				des1[numDes1 + additional] = (double*)malloc(sizeof(double) * 15);
				des1[numDes1 + additional][0] = des1[i][1];
				des1[numDes1 + additional][1] = des1[i][0];
				des1[numDes1 + additional][2] = des1[i][2];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 3] = des1[i][n + 3];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 6] = des1[i][n + 9];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 9] = des1[i][n + 6];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 12] = des1[i][n + 12];
				additional++;
			}
		}
		else 
		{
			if (des1[i][2] - des1[i][1] < threshold_angle) //ֻ��2,3�ܽӽ�
			{
				//��������1-3-2
				des1[numDes1 + additional] = (double*)malloc(sizeof(double) * 15);
				des1[numDes1 + additional][0] = des1[i][0];
				des1[numDes1 + additional][1] = des1[i][2];
				des1[numDes1 + additional][2] = des1[i][1];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 3] = des1[i][n + 6];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 6] = des1[i][n + 3];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 9] = des1[i][n + 9];
				for (int n = 0; n < 3; n++)
					des1[numDes1 + additional][n + 12] = des1[i][n + 12];
				additional++;
			}
		}
	}
	numDes1 += additional;

	printf("Descriptors for plane set 1 ready. %d combinations\n", numDes1);

	for (int i = 0; i < numPl2 - 2; i++)
		for (int j = i + 1; j < numPl2 - 1; j++)
			for (int k = j + 1; k < numPl2; k++)
			{
				for (int m = 0; m < 3; m++)
					rep[m][0] = pl2[i][m];
				for (int m = 0; m < 3; m++)
					rep[m][1] = pl2[j][m];
				for (int m = 0; m < 3; m++)
					rep[m][2] = pl2[k][m];
				if (fabs(det3(rep)) < threshold_linear)continue;//�������������棬��Ч
				angle1 = ang(pl2[i], pl2[j]) / deg;
				angle2 = ang(pl2[i], pl2[k]) / deg;
				angle3 = ang(pl2[j], pl2[k]) / deg;
				rev3(rep, rev);
				flip(rev);
				point[0] = pl2[i][3];
				point[1] = pl2[j][3];
				point[2] = pl2[k][3];
				leftMult(rev, point);

				des2[numDes2] = (double*)malloc(sizeof(double) * 15);
				des2[numDes2][0] = angle1;
				des2[numDes2][1] = angle2;
				des2[numDes2][2] = angle3;
				for (int n = 0; n < 3; n++)
					des2[numDes2][n + 3] = pl2[i][n];
				for (int n = 0; n < 3; n++)
					des2[numDes2][n + 6] = pl2[j][n];
				for (int n = 0; n < 3; n++)
					des2[numDes2][n + 9] = pl2[k][n];
				for (int n = 0; n < 3; n++)
					des2[numDes2][n + 12] = point[n];
				numDes2++;
			}

	for (int i = 0; i < numDes2; i++)//����
	{
		if (des2[i][0] > des2[i][1])
		{
			tmp = des2[i][0];
			des2[i][0] = des2[i][1];
			des2[i][1] = tmp;
			for (int j = 6; j < 9; j++)
			{
				tmp = des2[i][j];
				des2[i][j] = des2[i][j + 3];
				des2[i][j + 3] = tmp;
			}
		}
		if (des2[i][0] > des2[i][2])
		{
			tmp = des2[i][0];
			des2[i][0] = des2[i][2];
			des2[i][2] = tmp;
			for (int j = 3; j < 6; j++)
			{
				tmp = des2[i][j];
				des2[i][j] = des2[i][j + 6];
				des2[i][j + 6] = tmp;
			}
		}
		if (des2[i][1] > des2[i][2])
		{
			tmp = des2[i][1];
			des2[i][1] = des2[i][2];
			des2[i][2] = tmp;
			for (int j = 3; j < 6; j++)
			{
				tmp = des2[i][j];
				des2[i][j] = des2[i][j + 3];
				des2[i][j + 3] = tmp;
			}
		}
	}//des2�������
	printf("Descriptors for plane set 2 ready. %d combinations\n", numDes2);

	//�ȶԣ�Ѱ��ƥ��
	double **rep2;//��������ķ�������һ���������,�ڶ���
	rep2 = (double**)malloc(sizeof(double*) * 3);
	for (int i = 0; i < 3; i++)
		rep2[i] = (double*)malloc(sizeof(double) * 3);
	double **rot;//��ת����
	rot = (double**)malloc(sizeof(double*) * 3);
	for (int i = 0; i < 3; i++)
		rot[i] = (double*)malloc(sizeof(double) * 3);
	double *translation;//λ��
	translation = (double*)malloc(sizeof(double) * 3);
	int matchPl;//ƥ���ƽ����
	int **matchList;//ƥ���ƽ���б���matchPl*2�ṹ��ÿ�������ƽ�漯1ƽ��index���ұ���ƽ�漯2ƽ��index
	matchList = (int**)malloc(sizeof(int*)*numPl2);
	for (int i = 0; i < numPl2; i++)
		matchList[i] = (int*)malloc(sizeof(int) * 2);
	double score;//�����ķ������ݶ�Ϊ ƥ��ƽ����/ƽ�����

	//֮�����ǿ��Ǳ�����������������������
	double **rot_best;//��ת�������ղ��ð�
	rot_best = (double**)malloc(sizeof(double*) * 3);
	for (int i = 0; i < 3; i++)
		rot_best[i] = (double*)malloc(sizeof(double) * 3);
	double *translation_best;//λ�����ղ��ð�
	translation_best = (double*)malloc(sizeof(double) * 3);
	int matchPl_best = 0;//���ղ��ð�ƥ���ƽ����
	double score_best = 0;

	int **matchList_best;//ƥ���ƽ���б���matchPl*2�ṹ��ÿ�������ƽ�漯1ƽ��index���ұ���ƽ�漯2ƽ��index
	matchList_best = (int**)malloc(sizeof(int*)*numPl2);
	for (int i = 0; i < numPl2; i++)
		matchList_best[i] = (int*)malloc(sizeof(int) * 2);

	double **pl2_cal;//�������������ƽ�漯2����
	pl2_cal = (double**)malloc(sizeof(double*)*numPl2);
	for (int i = 0; i < numPl2; i++)
		pl2_cal[i] = (double*)malloc(sizeof(double) * 4);
	//�����Ż����ս���ĸ��໺��
	double **normal1;
	normal1 = (double**)malloc(sizeof(double*)*max_Pl);
	for (int i = 0; i < max_Pl; i++)
		normal1[i] = (double*)malloc(sizeof(double) * 3);
	double **normal2;
	normal2 = (double**)malloc(sizeof(double*)*max_Pl);
	for (int i = 0; i < max_Pl; i++)
		normal2[i] = (double*)malloc(sizeof(double) * 4);
	double **tmp33;
	tmp33 = (double**)malloc(sizeof(double*) * 3);
	for (int i = 0; i < 3; i++)
		tmp33[i] = (double*)malloc(sizeof(double) * 3);
	double *weight = (double*)malloc(sizeof(double)*numPl2);//Ȩ��
	
	int numMatchFound = 0;
	if (debugmode)
	{
		if (testmode)fpdb= fopen("C:\\Users\\Administrator\\Desktop\\reg\\debugInfo.txt", "w");
		else fpdb = fopen("debugInfo.txt", "w");
	}

	double yaw, pitch, roll, cosPitch, cosRoll, cosYaw;
	double **turnYaw = (double **)malloc(sizeof(double*) * 3);
	double **liftPitch = (double **)malloc(sizeof(double*) * 3);
	double **rotateRoll = (double **)malloc(sizeof(double*) * 3);
	for (int i = 0; i < 3; i++)
	{
		turnYaw[i] = (double*)malloc(sizeof(double) * 3);
		liftPitch[i] = (double*)malloc(sizeof(double) * 3);
		rotateRoll[i] = (double*)malloc(sizeof(double) * 3);
	}

	for (int i = 0; i < numDes2; i++)
		for (int j = 0; j < numDes1; j++)
			if (fabs(des2[i][0] - des1[j][0]) < threshold_angle)
				if (fabs(des2[i][1] - des1[j][1]) < threshold_angle)
					if (fabs(des2[i][2] - des1[j][2]) < threshold_angle)
					{
						for (int k = 3; k < 12; k++)
							rep[k % 3][k / 3 - 1] = des1[j][k];
						for (int k = 3; k < 12; k++)
							rep2[k % 3][k / 3 - 1] = des2[i][k];
						for (int k = 12; k < 15; k++)
							translation[k - 12] = des2[i][k];
						rev3(rep2, rev);
						matmul(rep, rev, rot);//rotation������ɡ������Ľ������
						
						svdApprox(rot, 3);//��svd�ֽ⽫��ת����������

						if (det3(rot) < 0)continue;
						if (pitch_roll_restriction)
						{
							if (rot[2][0] > 1)rot[2][0] = 1;
							if (rot[2][0] < -1)rot[2][0] = -1;
							pitch = asin(rot[2][0]);														
							cosPitch = cos(pitch);
							pitch /= deg;
							if (cosPitch == 0) { yaw = 0.0; roll = 0.0; }
							else
							{
								cosRoll = rot[2][2] / cosPitch;
								cosYaw = rot[0][0] / cosPitch;
								if (cosRoll > 1)cosRoll = 1;
								if (cosYaw > 1)cosYaw = 1;
								if (cosRoll < -1)cosRoll = -1;
								if (cosYaw < -1)cosYaw = -1;
								yaw = acos(cosYaw) / deg;
								roll = acos(cosRoll) / deg;
								if ((rot[1][0] / cosPitch) < 0)yaw *= -1;
								if ((rot[2][1] / cosPitch) < 0)roll *= -1;
							}
							if (yaw_restriction)
								if (fabs(yaw) > yaw_restriction)continue;
							if (fabs(roll) > pitch_roll_restriction)continue;
							if (fabs(pitch) > pitch_roll_restriction)continue;
						}

						//����translation
						leftMult(rot, translation);

						/*leftMult(rotateRoll, translation);
						leftMult(liftPitch, translation);
						leftMult(turnYaw, translation);*/


						for (int k = 0; k < 3; k++)
							translation[k] = des1[j][k + 12] - translation[k];
						if (translation_restriction)
							if ((translation[0] * translation[0] + translation[1] * translation[1] + translation[2] * translation[2]) >(translation_restriction*translation_restriction))continue;

						matchPl = evaluate(rot, translation, pl2, pl2_cal, numPl2, pl1, numPl1, matchList, &score, fpdb);
						
						if (debugmode)
						{
							fprintf(fpdb, "\nCandidate number %d\nRotation matrix:\n", ++numMatchFound);
							for (int p = 0; p < 3; p++)
							{
								for (int q = 0; q < 3; q++)
									fprintf(fpdb, "%lf ", rot[p][q]);
								fprintf(fpdb, "\n");
							}
							double th, ph, ya, co;
							ph = asin(rot[2][0]);
							co = cos(ph);
							ph /= deg;
							th = acos(rot[0][0] / co) / deg;
							ya = acos(rot[2][2] / co) / deg;
							if ((rot[1][0] / co) < 0)th *= -1;							
							if ((rot[2][1] / co) < 0)ya *= -1;
							fprintf(fpdb, "Rotation:\nYaw:%lf deg\nPitch:%lf deg\nRoll:%lf deg\n", th, ph, ya);
							fprintf(fpdb, "Translation:\n");
							for (int p = 0; p < 3; p++)
								fprintf(fpdb, "%lf ", translation[p]);
							fprintf(fpdb, "\n");
							fprintf(fpdb, "Matching planes: %d\n", matchPl);
							fprintf(fpdb, "Score: %lf\n", score);
							fprintf(fpdb, "Descriptor 1:\n");
							for (int p = 0; p < 3; p++)
								fprintf(fpdb, "%lf ", des1[j][p]);
							for (int p = 3; p < 15; p++)
								fprintf(fpdb, "%lf ", des1[j][p]);
							fprintf(fpdb, "\n");
							fprintf(fpdb, "Descriptor 2:\n");
							for (int p = 0; p < 3; p++)
								fprintf(fpdb, "%lf ", des2[i][p]);
							for (int p = 3; p < 15; p++)
								fprintf(fpdb, "%lf ", des2[i][p]);
							fprintf(fpdb, "\n");

							//fprintf(fpdb, "Error Angle: %lf, Error Translation: %lf\n\n", sqrt((30 + th)*(30 + th) + (30 + ph)*(30 + ph) + ya*ya), sqrt((translation[0] + 100)*(translation[0] + 100) + (translation[1] + 100)*(translation[1] + 100) + (translation[2] + 100)*(translation[2] + 100)));
						}

						if (numOnly)
						{
							if (matchPl > matchPl_best)
							{	
								if(weighted) //����Ȩ����Ϣ
									for (int mtc = 0; mtc < matchPl; mtc++)
										weight[mtc] = plPts1[matchList[mtc][0]] * plPts2[matchList[mtc][1]] / 250000.0;
								//�Ż����
								if (finalOptimization == 1)
								{
									optimize_rot(matchList, matchPl, pl1, pl2, rot, normal1, normal2, tmp33, rev, weight);
									svdApprox(rot, 3);//��svd�ֽ⽫��ת����������
									if(finalOptimization_tran)
										optimize_tran(matchList, matchPl, pl1, pl2, rot, normal2, tmp33, rev, translation, weight);
								}
								else
								{
									if (finalOptimization == 2)
									{
										optimize_homogeneous(matchList, matchPl, pl1, pl2, rot, normal1, normal2, tmp33, rev, translation, weight);
										svdApprox(rot, 3);//��svd�ֽ⽫��ת����������
									}
								}

								if (finalCheck)
								{
									if (det3(rot) < 0)continue;
									if (pitch_roll_restriction)
									{
										if (rot[2][0] > 1)rot[2][0] = 1;
										if (rot[2][0] < -1)rot[2][0] = -1;
										pitch = asin(rot[2][0]);
										cosPitch = cos(pitch);
										pitch /= deg;
										if (cosPitch == 0) { yaw = 0.0; roll = 0.0; }
										else
										{
											cosRoll = rot[2][2] / cosPitch;
											cosYaw = rot[0][0] / cosPitch;
											if (cosRoll > 1)cosRoll = 1;
											if (cosYaw > 1)cosYaw = 1;
											if (cosRoll < -1)cosRoll = -1;
											if (cosYaw < -1)cosYaw = -1;
											yaw = acos(cosYaw) / deg;
											roll = acos(cosRoll) / deg;
											if ((rot[1][0] / cosPitch) < 0)yaw *= -1;
											if ((rot[2][1] / cosPitch) < 0)roll *= -1;
										}
										if (yaw_restriction)
											if (fabs(yaw) > yaw_restriction)continue;
										if (fabs(roll) > pitch_roll_restriction)continue;
										if (fabs(pitch) > pitch_roll_restriction)continue;
										if (translation_restriction)
											if ((translation[0] * translation[0] + translation[1] * translation[1] + translation[2] * translation[2]) >(translation_restriction*translation_restriction))continue;
									}
								}

								//�������Ž��
								score_best = score;
								matchPl_best = matchPl;
								for (int sv = 0; sv < matchPl; sv++)
								{
									matchList_best[sv][0] = matchList[sv][0];
									matchList_best[sv][1] = matchList[sv][1];
								}
								for (int m = 0; m < 3; m++)
									for (int n = 0; n < 3; n++)
										rot_best[m][n] = rot[m][n];
								for (int m = 0; m < 3; m++)
									translation_best[m] = translation[m];
								if (matchPl_best == min(numPl1, numPl2))goto STOPCHECKING;
							}
						}
						else
						{
							if (score > score_best)
							{
								if (weighted) //����Ȩ����Ϣ
									for (int mtc = 0; mtc < matchPl; mtc++)
										weight[mtc] = plPts1[matchList[mtc][0]] * plPts2[matchList[mtc][1]] / 250000.0;
								//�Ż����
								if (finalOptimization == 1)
								{
									optimize_rot(matchList, matchPl, pl1, pl2, rot, normal1, normal2, tmp33, rev, weight);
									svdApprox(rot, 3);//��svd�ֽ⽫��ת����������
									if (finalOptimization_tran)
										optimize_tran(matchList, matchPl, pl1, pl2, rot, normal2, tmp33, rev, translation, weight);
								}
								else
								{
									if (finalOptimization == 2)
									{
										optimize_homogeneous(matchList, matchPl, pl1, pl2, rot, normal1, normal2, tmp33, rev, translation, weight);
										svdApprox(rot, 3);//��svd�ֽ⽫��ת����������
									}
								}

								if (finalCheck)
								{
									if (det3(rot) < 0)continue;
									if (pitch_roll_restriction)
									{
										if (rot[2][0] > 1)rot[2][0] = 1;
										if (rot[2][0] < -1)rot[2][0] = -1;
										pitch = asin(rot[2][0]);
										cosPitch = cos(pitch);
										pitch /= deg;
										if (cosPitch == 0) { yaw = 0.0; roll = 0.0; }
										else
										{
											cosRoll = rot[2][2] / cosPitch;
											cosYaw = rot[0][0] / cosPitch;
											if (cosRoll > 1)cosRoll = 1;
											if (cosYaw > 1)cosYaw = 1;
											if (cosRoll < -1)cosRoll = -1;
											if (cosYaw < -1)cosYaw = -1;
											yaw = acos(cosYaw) / deg;
											roll = acos(cosRoll) / deg;
											if ((rot[1][0] / cosPitch) < 0)yaw *= -1;
											if ((rot[2][1] / cosPitch) < 0)roll *= -1;
										}
										if (yaw_restriction)
											if (fabs(yaw) > yaw_restriction)continue;
										if (fabs(roll) > pitch_roll_restriction)continue;
										if (fabs(pitch) > pitch_roll_restriction)continue;
										if (translation_restriction)
											if ((translation[0] * translation[0] + translation[1] * translation[1] + translation[2] * translation[2]) >(translation_restriction*translation_restriction))continue;
									}
								}

								//�������Ž��
								score_best = score;
								matchPl_best = matchPl;
								for (int sv = 0; sv < matchPl; sv++)
								{
									matchList_best[sv][0] = matchList[sv][0];
									matchList_best[sv][1] = matchList[sv][1];
								}
								for (int m = 0; m < 3; m++)
									for (int n = 0; n < 3; n++)
										rot_best[m][n] = rot[m][n];
								for (int m = 0; m < 3; m++)
									translation_best[m] = translation[m];
								if (matchPl_best == min(numPl1, numPl2))goto STOPCHECKING;
							}
						}
					}
	STOPCHECKING:
	if (!matchPl_best)
	{
		printf("Fail. No match found.\n");
		//���ʧ�ܽ��
		fprintf(fp3, "Fail. No match found.\nRotation Matrix:\n");
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
				fprintf(fp3, "%lf ", (i == j) ? 1.0 : 0.0);
			fprintf(fp3, "\n");
		}
		fprintf(fp3, "Rotation:\nYaw:%lf deg\nPitch:%lf deg\nRoll:%lf deg\n", 0.0, 0.0, 0.0);
		fprintf(fp3, "Translation:\n");
		for (int i = 0; i < 3; i++)
			fprintf(fp3, "%lf ", 0.0);
		fprintf(fp3, "\n");
		fprintf(fp3, "Matching planes: %d\n", 0);

		fprintf(fp4, "%lf yaw\n", 0.0);
		fprintf(fp4, "%lf pitch\n", 0.0);
		fprintf(fp4, "%lf roll\n", 0.0);
		fprintf(fp4, "%lf tx\n", 0.0);
		fprintf(fp4, "%lf ty\n", 0.0);
		fprintf(fp4, "%lf tz\n", 0.0);
		//getch();
		return 0;
	}

	//�������matchList
	if (!testmode)
	{
		FILE *fpml;
		fpml = fopen("matchList.txt", "w");
		fprintf(fpml, "%d pairs found\n", matchPl_best);
		for (int i = 0; i < matchPl_best; i++)
			fprintf(fpml, "%d %d\n", matchList_best[i][0] + 1, matchList_best[i][1] + 1);
		fclose(fpml);
	}

	//������
	fprintf(fp3, "Best match:\nRotation Matrix:\n");
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
			fprintf(fp3, "%lf ", rot_best[i][j]);
			fprintf(fp3, "\n");
	}

	if (rot_best[2][0] > 1)rot_best[2][0] = 1;
	if (rot_best[2][0] < -1)rot_best[2][0] = -1;
	pitch = asin(rot_best[2][0]);	
	cosPitch = cos(pitch);
	pitch /= deg;
	if (cosPitch == 0) { yaw = 0.0; roll = 0.0; }
	else
	{
		cosRoll = rot_best[2][2] / cosPitch;
		cosYaw = rot_best[0][0] / cosPitch;
		if (cosRoll > 1)cosRoll = 1;
		if (cosYaw > 1)cosYaw = 1;
		if (cosRoll < -1)cosRoll = -1;
		if (cosYaw < -1)cosYaw = -1;
		yaw = acos(cosYaw) / deg;
		roll = acos(cosRoll) / deg;
		if ((rot_best[1][0] / cosPitch) < 0)yaw *= -1;
		if ((rot_best[2][1] / cosPitch) < 0)roll *= -1;
	}

	fprintf(fp3, "Rotation:\nYaw:%lf deg\nPitch:%lf deg\nRoll:%lf deg\n", yaw, pitch, roll);
	fprintf(fp3, "Translation:\n");
	for (int i = 0; i < 3; i++)
		fprintf(fp3, "%lf ", translation_best[i]);
	fprintf(fp3, "\n");
	fprintf(fp3, "Matching planes: %d\n", matchPl_best);

	fprintf(fp4, "%lf yaw\n", yaw);
	fprintf(fp4, "%lf pitch\n", pitch);
	fprintf(fp4, "%lf roll\n", roll);
	fprintf(fp4, "%lf tx\n", translation_best[0]);
	fprintf(fp4, "%lf ty\n", translation_best[1]);
	fprintf(fp4, "%lf tz\n", translation_best[2]);

	currentTime = clock() - currentTime;
	double timeUsed = ((double)currentTime) / CLOCKS_PER_SEC;

	printf("Registration successful.\nTime taken: %lf seconds\n", timeUsed);
	//printf("Press any key to exit.\n");
	//getch();
	return 1;
}


//����3*3�������,a�˵�b��ߣ�c�ǽ��
int matmul(double **a, double **b, double **c)
{
	double acc = 0;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
		{
			acc = 0;
			for (int k = 0; k < 3; k++)
				acc += a[i][k] * b[k][j];
			c[i][j] = acc;
		}
	return 1;
}

//ת��3*3����
int flip(double **m)
{
	double tmp;
	for (int i = 0; i < 2; i++)
		for (int j = i + 1; j < 3; j++)
		{
			tmp = m[i][j];
			m[i][j] = m[j][i];
			m[j][i] = tmp;
		}
	return 1;
}

//������λ�����ļн�(������)
double ang(double *v1, double *v2)
{
	return acos(v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2]);
}


//3���������3*3����
int leftMult(double **m, double *v)
{
	double x = v[0], y = v[1], z = v[2];
	v[0] = m[0][0] * x + m[0][1] * y + m[0][2] * z;
	v[1] = m[1][0] * x + m[1][1] * y + m[1][2] * z;
	v[2] = m[2][0] * x + m[2][1] * y + m[2][2] * z;
	return 0;
}

//�����׾�������ʽ
double det3(double **m)
{
	return m[0][0] * m[1][1] * m[2][2] - m[0][0] * m[1][2] * m[2][1] - m[0][1] * m[1][0] * m[2][2] + m[0][1] * m[1][2] * m[2][0] + m[0][2] * m[1][0] * m[2][1] - m[0][2] * m[1][1] * m[2][0];
}

//���׾���������
int rev3(double **m, double **result)
{
	double d = det3(m);
	if (!d)return 1;
	result[0][0] = (m[1][1] * m[2][2] - m[1][2] * m[2][1]) / d;
	result[1][0] = (m[1][2] * m[2][0] - m[1][0] * m[2][2]) / d;
	result[2][0] = (m[1][0] * m[2][1] - m[1][1] * m[2][0]) / d;
	result[0][1] = (m[0][2] * m[2][1] - m[0][1] * m[2][2]) / d;
	result[1][1] = (m[0][0] * m[2][2] - m[0][2] * m[2][0]) / d;
	result[2][1] = (m[0][1] * m[2][0] - m[0][0] * m[2][1]) / d;
	result[0][2] = (m[0][1] * m[1][2] - m[0][2] * m[1][1]) / d;
	result[1][2] = (m[0][2] * m[1][0] - m[1][2] * m[0][0]) / d;
	result[2][2] = (m[1][1] * m[0][0] - m[1][0] * m[0][1]) / d;
	return 0;
}

//���ݸ�����rotation�����translation����������׼���
int evaluate(double **rot, double *translation, double **pl2, double **pl2_cal, int numPl2, double **pl1, int numPl1, int **matchPlList, double *score, FILE *fpdb)
{
	for (int i = 0; i < numPl2; i++)
		for (int j = 0; j < 4; j++)
			pl2_cal[i][j] = pl2[i][j];
	for (int i = 0; i < numPl2; i++)
		leftMult(rot, pl2_cal[i]);
	for (int i = 0; i < numPl2; i++)
		pl2_cal[i][3] += translation[0] * pl2_cal[i][0] + translation[1] * pl2_cal[i][1] + translation[2] * pl2_cal[i][2];
	int match = 0;
	int matchID;
	double err = 0;
	if (singleMatch)
		for (int i = 0; i < numPl2; i++)
		{
			matchID = belong_only(pl2_cal[i], pl1, numPl1);
			if (matchID)
			{
				matchID--;
				//��match������в���ȷ��11��Ӧ
				if (belong_only(pl1[matchID], pl2_cal, numPl2))
				{
					matchPlList[match][0] = matchID;
					matchPlList[match][1] = i;
					match++;
				}
			}
		}
	else
	{
		for (int i = 0; i < numPl2; i++)
		{
			matchID = belong(pl2_cal[i], pl1, numPl1);
			if (matchID)
			{
				matchID--;
				matchPlList[match][0] = matchID;
				matchPlList[match][1] = i;
				match++;
			}
		}
	}

	if (debugmode)
	{
		fprintf(fpdb, "\nPlane set 2 after transformation:\n");
		for (int i = 0; i < numPl2; i++)
		{
			for (int j = 0; j < 4; j++)
				fprintf(fpdb, "%lf ", pl2_cal[i][j]);
			fprintf(fpdb, "\n");
		}
		fprintf(fpdb, "Matching List:\n");
		for (int i = 0; i < match; i++)
			fprintf(fpdb, "%d %d\n", matchPlList[i][0], matchPlList[i][1]);
	}

	if (match > 2)
	{
		if (!numOnly) //���㵱ǰƥ�����÷�
		{
			for (int i = 0; i < match; i++) //Ŀǰ���õ����������ŷ�Ͼ���
				err += sqrt((pl1[matchPlList[i][0]][3] * pl1[matchPlList[i][0]][0] - pl2[matchPlList[i][1]][3] * pl2[matchPlList[i][1]][0])*(pl1[matchPlList[i][0]][3] * pl1[matchPlList[i][0]][0] - pl2[matchPlList[i][1]][3] * pl2[matchPlList[i][1]][0]) + (pl1[matchPlList[i][0]][3] * pl1[matchPlList[i][0]][1] - pl2[matchPlList[i][1]][3] * pl2[matchPlList[i][1]][1])*(pl1[matchPlList[i][0]][3] * pl1[matchPlList[i][0]][1] - pl2[matchPlList[i][1]][3] * pl2[matchPlList[i][1]][1]) + (pl1[matchPlList[i][0]][3] * pl1[matchPlList[i][0]][2] - pl2[matchPlList[i][1]][3] * pl2[matchPlList[i][1]][2])*(pl1[matchPlList[i][0]][3] * pl1[matchPlList[i][0]][2] - pl2[matchPlList[i][1]][3] * pl2[matchPlList[i][1]][2]));
			err /= match;
			*score = match / err;
		}
		return match;
	}
	else *score = 0;
	return 0;
}

//���ݸ�����rotation�����translation������ground Truth������׼���
int evaluateGT(double **rot, double *translation, double **pl2, double **pl2_cal, int numPl2, double **pl1, int numPl1, int **matchPlList, double *score)
{
	double th, ph, ya, co;
	ph = asin(rot[2][0]);
	co = cos(ph);
	ph /= deg;
	th = acos(rot[0][0] / co) / deg;
	ya = acos(rot[2][2] / co) / deg;
	if ((rot[1][0] / co) < 0)th *= -1;
	if ((rot[2][1] / co) < 0)ya *= -1;
	double err = 0;
	err += (th - (GTyaw))*(th - (GTyaw));
	err += (ph - (GTpitch))*(ph - (GTpitch));
	err += (ya - (GTroll))*(ya - (GTroll));
	err += (translation[0] - (GTtx))*(translation[0] - (GTtx));
	err += (translation[1] - (GTty))*(translation[1] - (GTty));
	err += (translation[2] - (GTtz))*(translation[2] - (GTtz));
	err = sqrt(err);
	*score = -err;

	for (int i = 0; i < numPl2; i++)
		for (int j = 0; j < 4; j++)
			pl2_cal[i][j] = pl2[i][j];
	for (int i = 0; i < numPl2; i++)
		leftMult(rot, pl2_cal[i]);
	for (int i = 0; i < numPl2; i++)
		pl2_cal[i][3] += translation[0] * pl2_cal[i][0] + translation[1] * pl2_cal[i][1] + translation[2] * pl2_cal[i][2];
	int match = 0;
	int matchID;
	
	for (int i = 0; i < numPl2; i++)
	{
		matchID = belong(pl2_cal[i], pl1, numPl1);
		if (matchID)
		{
			matchID--;
			matchPlList[match][0] = matchID;
			matchPlList[match][1] = i;
			match++;
		}
	}
	if (match < 3)*score = 0;
	return match;
}

//����ƽ���Ƿ���Ϊһ��
int samePl(double *pl1, double *pl2)
{
	if (fabs(pl1[0] - pl2[0]) > samePl_normal)return 0;
	if (fabs(pl1[1] - pl2[1]) > samePl_normal)return 0;
	if (fabs(pl1[2] - pl2[2]) > samePl_normal)return 0;
	if (fabs(pl1[3] - pl2[3]) > samePl_dist)return 0;
	return 1;
}

//���һ��ƽ���Ƿ���ƽ�漯��
int belong(double *pl, double **pl1,int *numPl1)
{
	for (int i = 0; i < numPl1; i++)
		if (samePl(pl, pl1[i]))
		{
			int bestID = i + 1;
			double bestErr = fabs(pl[3] - pl1[i][3]);
			double Err;
			for (i = i + 1; i < numPl1; i++)
				if (samePl(pl, pl1[i]))
				{
					Err= fabs(pl[3] - pl1[i][3]);
					if (Err < bestErr)
						bestID = i + 1;
					bestErr = Err;
				}
			return bestID;
		}
	return 0;
}

//���һ��ƽ���Ƿ���ƽ�漯��,����Ψһ��Ӧ
int belong_only(double *pl, double **pl1, int *numPl1)
{
	int found = 0, bestID;
	for (int i = 0; i < numPl1; i++)
		if (samePl(pl, pl1[i]))
		{
			bestID = i + 1;
			found++;
		}
	if (found != 1)return 0;
	else return bestID;
}

//����ƥ���ƽ�漯�Ż�rot������
void optimize_rot(int **matchList, int numMatch, double **pl1, double **pl2, double **rot, double **normal1, double **normal2, double **tmp33, double **rev, double *weight)
{
	for (int i = 0; i < numMatch; i++)
		for (int j = 0; j < 3; j++)
		{
			normal2[i][j] = pl1[matchList[i][0]][j];
			normal1[i][j] = pl2[matchList[i][1]][j];
		}
	double acc;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
		{
			acc = 0;
			if (weighted)
				for (int k = 0; k < numMatch; k++)
					acc += normal1[k][i] * normal1[k][j] * weight[k];
			else
				for (int k = 0; k < numMatch; k++)
					acc += normal1[k][i] * normal1[k][j];
			tmp33[i][j] = acc;
		}
	rev3(tmp33, rev);
	
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
		{
			acc = 0;
			if (weighted)
				for (int k = 0; k < numMatch; k++)
					acc += normal1[k][i] * normal2[k][j] * weight[k];
			else
				for (int k = 0; k < numMatch; k++)
					acc += normal1[k][i] * normal2[k][j];
			tmp33[i][j] = acc;
		}
	matmul(rev, tmp33, rot);
	flip(rot);
}

//����ƥ���ƽ�漯�Ż�translation�������
void optimize_tran(int **matchList, int numMatch, double **pl1, double **pl2, double **rot, double **normal2, double **tmp33, double **rev, double *tran, double *weight)
{
	for (int i = 0; i < numMatch; i++)
		for (int j = 0; j < 3; j++)
			normal2[i][j] = pl2[matchList[i][1]][j];
	double acc;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
		{
			acc = 0;
			if (weighted)
				for (int k = 0; k < numMatch; k++)
					acc += normal2[k][i] * normal2[k][j] * weight[k];
			else
				for (int k = 0; k < numMatch; k++)
					acc += normal2[k][i] * normal2[k][j];
			tmp33[i][j] = acc;
		}
	rev3(tmp33, rev);
	double *b = (double*)malloc(sizeof(double)*numMatch);
	for (int i = 0; i < numMatch; i++)
		b[i] = pl1[matchList[i][0]][3] - pl2[matchList[i][1]][3];
	for (int i = 0; i < 3; i++)
	{
		acc = 0;
		if (weighted)
			for (int k = 0; k < numMatch; k++)
				acc += normal2[k][i] * b[k] * weight[k];
		else
			for (int k = 0; k < numMatch; k++)
				acc += normal2[k][i] * b[k];
		tran[i] = acc;
	}
	free(b);
	leftMult(rev, tran);
	leftMult(rot, tran);
}

//����ƥ���ƽ�漯�Ż�����motion���
void optimize_homogeneous(int **matchList, int numMatch, double **pl1, double **pl2, double **rot, double **normal1, double **normal2, double **tmp33, double **rev, double *tran, double *weight)
{
	for (int i = 0; i < numMatch; i++)
		for (int j = 0; j < 3; j++)
			normal1[i][j] = pl2[matchList[i][1]][j];
	for (int i = 0; i < numMatch; i++)
	{
		for (int j = 0; j < 3; j++)
			normal2[i][j] = pl1[matchList[i][0]][j];
		normal2[i][3] = pl1[matchList[i][0]][3] - pl2[matchList[i][1]][3];
	}
	double acc;
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
		{
			acc = 0;
			if (weighted)
				for (int k = 0; k < numMatch; k++)
					acc += normal1[k][i] * normal1[k][j] * weight[k];
			else
				for (int k = 0; k < numMatch; k++)
					acc += normal1[k][i] * normal1[k][j];
			tmp33[i][j] = acc;
		}
	rev3(tmp33, rev);
	double **b = (double**)malloc(sizeof(double*) * 3);
	for (int i = 0; i < 3; i++)
		b[i] = (double*)malloc(sizeof(double) * 4);
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 4; j++)
		{
			acc = 0;
			if (weighted)
				for (int k = 0; k < numMatch; k++)
					acc += normal1[k][i] * normal2[k][j] * weight[k];
			else
				for (int k = 0; k < numMatch; k++)
					acc += normal1[k][i] * normal2[k][j];
			b[i][j] = acc;
		}
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 4; j++)
		{
			acc = 0;
			for (int k = 0; k < 3; k++)
				acc += rev[i][k] * b[k][j];
			if (j == 3)tran[i] = acc;
			else rot[j][i] = acc;
		}
	free(b);
}