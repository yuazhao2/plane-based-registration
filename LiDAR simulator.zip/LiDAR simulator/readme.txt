This is a LiDAR simulator which creates simulated LiDAR point clouds using CAD models.
To use, rename the 3D model to scene_1.off and use it to replace the file in this folder. Open scene_1_location_1.txt and edit the parameters of the scanner, the first three parameters is the (x, y, z) of the scanner in the model's coordinate system. Yaw is the angle to rotate counterclockwise around the Z axis, pitch is the angle lifted from the horizontol plane. The rest of the parameters are not important. Save the modified file, and run [create simulated LiDAR point cloud].bat, the system will take care of the rest.
The output contains a clean point cloud and a noisy version which contains Gaussian noise. 

Notes:
1. The simulator works with PURE TRIANGULAR .off file. Other forms such as .obj can be converted to this format using the software meshLab. Remember to convert it to pure triangular mesh before exporting.
2. The unit is mm.
