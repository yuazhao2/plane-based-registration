#include <stdio.h>

void main(int argc, char *argv[])
{
	FILE *fp;
	fp = fopen("[getMotion].bat", "w");

	for (int i = 0; i <= 120; i++)
		fprintf(fp, "register.exe scene_1_location_1_planeSet.txt %d_planeSet.txt\nren registration_result.txt motion_modelLocation01_%d.txt\n", i, i);
	for (int i = 121; i <= 1036; i++)
		fprintf(fp, "register.exe scene_1_location_2_planeSet.txt %d_planeSet.txt\nren registration_result.txt motion_modelLocation02_%d.txt\n", i, i);
	for (int i = 1037; i <= 1186; i++)
		fprintf(fp, "register.exe scene_1_location_1_planeSet.txt %d_planeSet.txt\nren registration_result.txt motion_modelLocation01_%d.txt\n", i, i);

}