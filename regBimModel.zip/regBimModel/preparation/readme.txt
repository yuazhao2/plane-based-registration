This module is used to generate the .bat file used to perform a whole set of registration.
Edit the code in [getMotionsBatGenerator].c to suit specific needs, then save and run [getBAT].bat
The result would be an [getMotion].bat
copy it to the directory where experiment is performed and run.