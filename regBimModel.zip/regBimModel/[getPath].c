#include <stdio.h>
#include <math.h>

#define lift 4000.0
double tolerence = 100.0;

void main(int argc, char *argv[])
{
	FILE *fp;
	FILE *fp2;
	fp2 = fopen("[path].obj", "w");
	FILE *fp3;
	fp3 = fopen("[trajectory].txt", "w");
	char name[1000];
	double x, y, z, last[3];	
	int read, jump = 1, discard = 0;
	fprintf(fp2, "mtllib randomColor.mtl\ng path\nusemtl color1\n");

	//����һ����׼������ǲ��ɿ����Ǻ���Ͳ�����
	sprintf(name, "motion_modelLocation01_0.txt");
	fp = fopen(name, "r");
	for (int j = 0; j < 10; j++)
		do { read = fgetc(fp); } while (read != '\n');
	fscanf(fp, "%lf %lf %lf", &x, &y, &z);
	fclose(fp);
	last[0] = x;
	last[1] = y;
	last[2] = z;
	fprintf(fp2, "v %lf %lf %lf\n", x, y, z + lift);
	fprintf(fp3, "0 %lf %lf %lf\n", x, y, z);
	for (int i = 1; i <= 120; i++)
	{
		sprintf(name, "motion_modelLocation01_%d.txt", i);
		fp = fopen(name, "r");
		for (int j = 0; j < 10; j++)
			do { read = fgetc(fp); } while (read != '\n');
		fscanf(fp, "%lf %lf %lf", &x, &y, &z);
		fclose(fp);
		if (sqrt((last[0] - x)*(last[0] - x) + (last[1] - y)*(last[1] - y) + (last[2] - z)*(last[2] - z)) < jump*tolerence)
		{
			fprintf(fp2, "v %lf %lf %lf\n", x, y, z + lift);
			fprintf(fp2, "l -2 -1\n");
			last[0] = x;
			last[1] = y;
			last[2] = z;
			jump = 1;
			fprintf(fp3, "%d %lf %lf %lf\n", i, x, y, z);
		}
		else
		{
			jump++;
			discard++;
			fprintf(fp3, "%d UNKNOWN\n", i);
		}
	}
	for (int i = 121; i <= 1036; i++)
	{
		sprintf(name, "motion_modelLocation02_%d.txt", i);
		fp = fopen(name, "r");
		for (int j = 0; j < 10; j++)
			do { read = fgetc(fp); } while (read != '\n');
		fscanf(fp, "%lf %lf %lf", &x, &y, &z);
		fclose(fp);

		x += 2500.0;
		y -= 4000.0;

		if (sqrt((last[0] - x)*(last[0] - x) + (last[1] - y)*(last[1] - y) + (last[2] - z)*(last[2] - z)) < jump*tolerence)
		{
			fprintf(fp2, "v %lf %lf %lf\n", x, y, z + lift);
			fprintf(fp2, "l -2 -1\n");
			last[0] = x;
			last[1] = y;
			last[2] = z;
			jump = 1;
			fprintf(fp3, "%d %lf %lf %lf\n", i, x, y, z);
		}
		else
		{
			jump++;
			discard++;
			fprintf(fp3, "%d UNKNOWN\n", i);
		}
	}
	for (int i = 1037; i <= 1186; i++)
	{
		sprintf(name, "motion_modelLocation01_%d.txt", i);
		fp = fopen(name, "r");
		for (int j = 0; j < 10; j++)
			do { read = fgetc(fp); } while (read != '\n');
		fscanf(fp, "%lf %lf %lf", &x, &y, &z);
		fclose(fp);
		if (sqrt((last[0] - x)*(last[0] - x) + (last[1] - y)*(last[1] - y) + (last[2] - z)*(last[2] - z)) < jump*tolerence)
		{
			fprintf(fp2, "v %lf %lf %lf\n", x, y, z + lift);
			fprintf(fp2, "l -2 -1\n");
			last[0] = x;
			last[1] = y;
			last[2] = z;
			jump = 1;
			fprintf(fp3, "%d %lf %lf %lf\n", i, x, y, z);
		}
		else
		{
			jump++;
			discard++;
			fprintf(fp3, "%d UNKNOWN\n", i);
		}
	}
}