This experiment register the 1187 point clouds to the BIM model.
Copy all the plane sets supplied within this demo to this folder, click [getMotion].bat
Then after it's finished click [getPath].bat to acquire the final results.
Open scene_1_noCeiling.off, then stack [path].obj upon it to get a visualization of the final result.