Just copt the [motionSet].txt acquired from stitch module to this folder, click [getObjFromSuppliedMotionSet].bat

The trajectory will be in [trajectory].txt, the first three values of each line is the location, the next three would be a standard vector pointing towards the current 'forward' direction, then 'left', then 'up'.

[path].obj would be the visualized version of trajectory. Stack it with the .off model file provides better reference. 