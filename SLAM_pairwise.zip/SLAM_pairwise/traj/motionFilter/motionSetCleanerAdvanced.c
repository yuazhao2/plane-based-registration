#include <stdio.h>
#include <math.h>
#include <malloc.h>

#define threshold_roll 5.0
#define threshold_pitch 5.0
#define threshold_yaw 30.0
#define threshold_tran 50.0

double **motion;


void main(int argc, char *argv[])
{
	motion = (double**)malloc(sizeof(double*) * 5000);	
	FILE *fp;
	fp = fopen(argv[1], "r");
	FILE *fp2;
	fp2 = fopen("[motionSet_clean].txt", "w");
	int num = 0, end;
	motion[num] = (double*)malloc(sizeof(double) * 6);
	end = fscanf(fp, "%lf %lf %lf %lf %lf %lf\n", &motion[num][0], &motion[num][1], &motion[num][2], &motion[num][3], &motion[num][4], &motion[num][5]);
	while (end != EOF)
	{
		num++;
		motion[num] = (double*)malloc(sizeof(double) * 6);		
		end = fscanf(fp, "%lf %lf %lf %lf %lf %lf\n", &motion[num][0], &motion[num][1], &motion[num][2], &motion[num][3], &motion[num][4], &motion[num][5]);
	}

	for (int i = 0; i < num; i++)
	{
		if (!valid(i))
		{
			if (i == 0)
			{
				if (valid(1))
					for (int j = 0; j < 6; j++)
						motion[0][j] = motion[1][j];
				else zero(0);
			}
			else if (i == num - 1)
			{
				if (valid(num - 2))
					for (int j = 0; j < 6; j++)
						motion[num - 1][j] = motion[num - 2][j];
				else zero(num - 1);
			}
			else
			{
				if (valid(i - 1) && valid(i + 1))
					for (int j = 0; j < 6; j++)
						motion[i][j] = (motion[i + 1][j] + motion[i - 1][j]) / 2;
				else if(valid(i - 1))
					for (int j = 0; j < 6; j++)
						motion[i][j] = motion[i-1][j];
				else if (valid(i + 1))
					for (int j = 0; j < 6; j++)
						motion[i][j] = motion[i + 1][j];
				else zero(i);
			}
		}
	}
	for (int i = 0; i < num; i++)
		fprintf(fp2, "%lf %lf %lf %lf %lf %lf\n", motion[i][0], motion[i][1], motion[i][2], motion[i][3], motion[i][4], motion[i][5]);
}

int zero(int m)
{
	for (int i = 0; i < 6; i++)
		motion[m][i] = 0;
	return 0;
}

int valid(int m)
{
	if ((motion[m][0] == 0) && (motion[m][1] == 0) && (motion[m][2] == 0) && (motion[m][3] == 0) && (motion[m][4] == 0) && (motion[m][5] == 0))return 0;
	if (fabs(motion[m][0]) > threshold_roll)return 0;
	if (fabs(motion[m][1]) > threshold_pitch)return 0;
	if (fabs(motion[m][2]) > threshold_yaw)return 0;
	if (sqrt(motion[m][3] * motion[m][3] + motion[m][4] * motion[m][4] + motion[m][5] * motion[m][5]) > threshold_tran)return 0;
	return 1;
}