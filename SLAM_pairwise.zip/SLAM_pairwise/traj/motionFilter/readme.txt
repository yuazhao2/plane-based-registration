This module is used to clean the motion set to remove absurd results to prevent occasional faulty registration to set the whole trajectory far off-course.
This is no longer needed with the new and more reliable registration method.

To use, simply drag the motionSet file onto motionSetCleaner.exe
The advanced version doesn't perform any better. Not in use.