#include <stdio.h>
#include <math.h>

#define threshold_roll 5.0
#define threshold_pitch 5.0
#define threshold_yaw 30.0
#define threshold_tran 50.0

double roll, pitch, yaw, tran[3];

void main(int argc, char *argv[])
{
	int end;
	int throwaway = 0;
	int num = 0;
	FILE *fp;
	fp = fopen(argv[1], "r");
	FILE *fp2;
	fp2 = fopen("[motionSet_clean].txt", "w");
	end = fscanf(fp, "%lf %lf %lf %lf %lf %lf\n", &roll, &pitch, &yaw, &tran[0], &tran[1], &tran[2]);
	while (end != EOF)
	{
		num++;
		if (!valid())
		{
			zero();
			throwaway++;
			printf("Motion %d has been discarded.\n", num);
		}
		fprintf(fp2, "%lf %lf %lf %lf %lf %lf\n", roll, pitch, yaw, tran[0], tran[1], tran[2]);
		end = fscanf(fp, "%lf %lf %lf %lf %lf %lf\n", &roll, &pitch, &yaw, &tran[0], &tran[1], &tran[2]);
	}
	printf("Cleaning completed. %d motions has been thrown away.\n", throwaway);
	getch();
}

int zero(void)
{
	roll = 0;
	pitch = 0;
	yaw = 0;
	for (int i = 0; i < 3; i++)tran[i] = 0;
	return 0;
}

int valid(void)
{
	if (fabs(roll) > threshold_roll)return 0;
	if (fabs(pitch) > threshold_pitch)return 0;
	if (fabs(yaw) > threshold_yaw)return 0;
	if (sqrt(tran[0] * tran[0] + tran[1] * tran[1] + tran[2] * tran[2]) > threshold_tran)return 0;
	return 1;
}