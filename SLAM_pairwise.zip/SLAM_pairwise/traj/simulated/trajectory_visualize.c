#include<stdio.h>

#define testmode 0

//ƫ����������ʱ��Ҫ�ѹ켣�ƶ�һ�²��ܿ����
#define off_x 0.0
#define off_y 0.0
#define off_z 2000.0

void main(int argc, char *argv[])
{
	FILE *fp;
	if (testmode == 2)fp = fopen("C:\\Users\\ZHAO YUAN\\Desktop\\traj\\[trajectory].txt", "r");
	if (!testmode)fp = fopen(argv[1], "r");
	FILE *fp2;
	if (testmode == 2)fp2 = fopen("C:\\Users\\ZHAO YUAN\\Desktop\\traj\\[path].obj", "w");
	if (!testmode)fp2 = fopen("[path].obj", "w");
	fprintf(fp2, "mtllib randomColor.mtl\ng path\nusemtl color1\n");
	double point[3];
	int end = fscanf(fp, "%lf %lf %lf", &point[0], &point[1], &point[2]);
	do { end = fgetc(fp); } while (end != '\n');
	fprintf(fp2, "v %lf %lf %lf\n", point[0] + off_x, point[1] + off_y, point[2] + off_z);
	end = fscanf(fp, "%lf %lf %lf", &point[0], &point[1], &point[2]);
	while (end != EOF)
	{
		do { end = fgetc(fp); } while (end != '\n');
		fprintf(fp2, "v %lf %lf %lf\nl -2 -1\n", point[0] + off_x, point[1] + off_y, point[2] + off_z);
		end = fscanf(fp, "%lf %lf %lf", &point[0], &point[1], &point[2]);
	}
	if (testmode)
	{
		printf("Visualization completed.\n");
		getch();
	}
}