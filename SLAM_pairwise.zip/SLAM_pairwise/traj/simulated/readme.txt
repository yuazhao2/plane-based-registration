Not for use with real data.
These files are used to create a set of parameters for the LiDAR simulator according to the movement method desired.
Use trajectory_generator.c to create a [motionSet].txt, containing ground truth motions
Then use the motionTOtrajectory.exe to create the ground truth trajectory, [trajectory].txt
(Or simply click [getTrajectory].bat)

Then, use the program compiled from trajectoryFORscanner.c to generate a series of location files to pass to the  LiDAR simulator and the [scan].bat to perform the whole set of simulation. The simulator will use these locations to create a whole set of point clouds.
(Or simply click [getPointClouds].bat once the [trajectory].txt is acquired).