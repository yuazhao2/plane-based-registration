This is the result of pairwise registration of 1187 point clouds.
The motion between point clouds are stored in [motionSet].txt, first three values are roll, pitch, yaw angle, the following three is the translation vector. Unit mm.
Open scene_1_adjusted_noCeiling.off and then stack [path].obj upon it provides a visualization of the result.

To perform the experiment with supplied data or new dataset, follow instructions in stitch folder.