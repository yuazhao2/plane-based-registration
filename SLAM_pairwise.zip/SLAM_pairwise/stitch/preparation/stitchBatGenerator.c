#include <stdio.h>

#define visualize 0 //�Ƿ��ϵ��ƽ��п��ӻ�����ʱ�ܾã�����ǵ������ģ���0Ϊ��1Ϊ��

void main(int argc, char *argv[])
{
	FILE *fp;
	fp = fopen("[stitch].bat", "w");
	int start, end, step;
	printf("Please enter the start number:\n");
	scanf("%d", &start);
	printf("Please enter the end number:\n");
	scanf("%d", &end);
	printf("Please enter the step length:\n");
	scanf("%d", &step);
	for (int i = start; i <= end; i+= step)
		fprintf(fp, "planeExtractor.exe %d.pcd\n", i);
	if (visualize)
	{
		fprintf(fp, "register.exe %d_planeSet.txt %d_planeSet.txt\n", start + step, start);
		fprintf(fp, "ren registration_result.txt motion_%d_%d.txt\n", start + step, start);
		fprintf(fp, "visualize.exe %d.pcd %d.pcd registration_result_motion.txt\n", start + step, start);
		for (int i = start + 2 * step; i <= end; i += step)
		{
			fprintf(fp, "ren result.pcd last.pcd\n");
			fprintf(fp, "register.exe %d_planeSet.txt %d_planeSet.txt\n", i, i - step);
			fprintf(fp, "ren registration_result.txt motion_%d_%d.txt\n", i, i - step);
			fprintf(fp, "visualize.exe %d.pcd last.pcd registration_result_motion.txt\n", i);
			fprintf(fp, "del last.pcd\n");
		}
	}
	else
	{
		fprintf(fp, "register.exe %d_planeSet.txt %d_planeSet.txt\n", start, start + step);
		fprintf(fp, "ren registration_result.txt motion_%d_%d.txt\n", start, start + step);
		for (int i = start + 2 * step; i <= end; i += step)
		{			
			fprintf(fp, "register.exe %d_planeSet.txt %d_planeSet.txt\n", i - step, i);
			fprintf(fp, "ren registration_result.txt motion_%d_%d.txt\n", i - step, i);
		}
		fprintf(fp, "del registration_result_motion.txt\n");
		for (int i = start; i <= end; i += step)
			fprintf(fp, "del %d_planeSet.txt\n", i);
	}
}