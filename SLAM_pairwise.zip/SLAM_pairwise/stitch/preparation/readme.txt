This module prepares the .bat file used to perform pairwise registration between a set of point clouds.
Usually the code do not need to be edited.
Just run [recompile].bat, it will create a [stitchBatGenerator].exe
Run it, follow the prompts.
The result should be a [stitch].bat
copy that to the experiment folder, and run.