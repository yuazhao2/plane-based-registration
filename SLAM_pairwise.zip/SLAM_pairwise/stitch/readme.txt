Put all the planeSets (supplied within this demo) into this folder, click [regONLY].bat to automatically perform pairwise registration.
After it's finished, run stitchResultGatherer.exe, follow the prompt to automatically gather all the motions into a single file [motionSet].txt to be processed further in the traj folder.

Note: This register.exe is specifically optimized for SLAM pairwise registration. Not to be used for general purpose registration with small overlap.

To use with other data than the supplied 1187 point clouds, use the program in preparation folder (instructions inside the folder) to get a [stitch].bat, copy that and all the point clouds back here. The point clouds should come in .pcd format, ASCII rather than binary.