#include<stdio.h>
//Last Updated 2021.3.15
//���ڽ�����stitch�Ľ�����ܵ�һ��[motionSet].txt�ļ��У��νӹ켣visualization�ȳ���
void main(int argc, char *argv[])
{
	int start, end, step;
	printf("Please enter the start number:\n");
	scanf("%d", &start);
	printf("Please enter the end number:\n");
	scanf("%d", &end);
	printf("Please enter the step length:\n");
	scanf("%d", &step);
	FILE *fp;
	fp = fopen("[motionSet].txt", "w");
	FILE *fp2;
	char name[1000];
	double tran[3];
	double roll, pitch, yaw;
	int read;
	for (int i = start; i + step <= end; i += step)
	{
		sprintf(name, "motion_%d_%d.txt", i, i + step);
		fp2 = fopen(name, "r");
		for (int j = 0; j < 6; j++)
			do { read = fgetc(fp2); } while (read != '\n');
		fscanf(fp2, "Yaw:%lf", &yaw);
		do { read = fgetc(fp2); } while (read != '\n');
		fscanf(fp2, "Pitch:%lf", &pitch);
		do { read = fgetc(fp2); } while (read != '\n');
		fscanf(fp2, "Roll:%lf", &roll);
		do { read = fgetc(fp2); } while (read != '\n');
		do { read = fgetc(fp2); } while (read != '\n');
		fscanf(fp2, "%lf %lf %lf", &tran[0], &tran[1], &tran[2]);
		fclose(fp2);
		fprintf(fp, "%lf %lf %lf %lf %lf %lf\n", roll, pitch, yaw, tran[0], tran[1], tran[2]);
	}
}