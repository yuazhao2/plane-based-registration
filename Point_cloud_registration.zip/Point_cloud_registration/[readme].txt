This is a complete demo of the entire point cloud registration system.
To register two point clouds, rename them to 1.pcd and 2.pcd and use them to replace the ones contained in this folder. Run [RegisterPointCloud].bat, the system will take care of the rest automatically.
The result is stored in registration_result.txt
The result is visualized. Open result.pcd to check it.
Plane extraction is also visualized. Check the two corresponding .obj file to see it. Also, stack the obj file with the pcd file can give you better comparison.

Note:
1. Only works with the supplied form of point cloud. Use text editor to open 1.pcd to see the details of the required format.
2. Works best with LiDAR point clouds, where the scanner is located at origin point (0,0,0). Other point clouds may have unreliable results. The unit of the coordinates is mm.
